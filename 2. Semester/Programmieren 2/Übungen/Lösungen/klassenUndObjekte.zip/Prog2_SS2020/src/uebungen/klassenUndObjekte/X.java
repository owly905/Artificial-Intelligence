package uebungen.klassenUndObjekte;

public class X {
	
	// statisches Attribut "zaehler"
	static private int zaehler = 0; // noch kein Objekt gez�hlt!

	public X() {
		zaehler++;
	}
	
	static public int getZaehler() {
		return zaehler;
	}
	
	public static void main(String[] args) {
		// einige X-Objekte erzeugen...
		X x1 = new X();
		X x2 = new X();
		X x3 = new X();
		System.out.println("es gibt " + getZaehler() + " X-Objekte!");
	}
}
