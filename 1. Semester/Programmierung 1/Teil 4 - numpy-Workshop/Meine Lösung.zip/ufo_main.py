from py4j.java_gateway import JavaGateway
from operator import itemgetter
from ufo_autopilot import flight_distance_mult
from ufo_autopilot import fly_to
from ufo_autopilot import distance_from_zero
from ufo_routing import fac
from ufo_routing import find_shortest_route
from ufo_protocol import plot_protocol

# Initialisierung des Gateways
gateway = JavaGateway()

# Referenz auf Simulation
sim = gateway.entry_point
sim.reset()

# View-Fenster, Skalierung (x m pro Pixel).
sim.openViewWindow(False, True, 5)

# Startpunkt s = (0, 0)
s = (0, 0)

# Zielpunkte p = (x, y) und Flughöhe z
p = [(-2.5, 32.0), (-39.0, 10.0), (24.0, 22.5), (-30.0, -20.0)]
p = find_shortest_route(p) # kürzeste Route
# p.sort(key=itemgetter(0)) # nach x-Koordinate austeigend sortiert
# p.sort(key=distance_from_zero) # nach Abstand von (0,0) sortiert
z = 5.0

for destination in p:
    x, y = destination
    sim.addDestination(x, y)

# Simulationsgeschwindigkeit
sim.setSpeedup(10)

# auf Eingabe warten
input("Press return to start...")

# Anzahl möglicher Routen, zu fliegenden Distanz
print("{} possible routes".format(fac(len(p))))
print("flight-distance: {}".format(flight_distance_mult(p, z)))

# Fliege das Ufo zu den Zielen, am Ende zum Ausgangspunkt
for destination in p:
    fly_to(sim, destination, z)
else:
    fly_to(sim, s, z)

# tatsächlich geflogenen Distanz
print("actual flight-distance: {}".format(sim.getDist()))

plot_protocol(p)
