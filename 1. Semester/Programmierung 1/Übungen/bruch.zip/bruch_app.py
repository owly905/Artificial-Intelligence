from bruch import add
from bruch import mult

# Beispieleingaben: "-5/4 + 7/6", "1/-2 * 1/2", Ausgaben: "= -1/12", "= -1/4"
eingabe = input()

if eingabe.find("+") >= 0:
    operation = "+"
    position = eingabe.find("+")
elif eingabe.find("*") >= 0:
    operation = "*"
    position = eingabe.find("*")
else:
    position = -1

if position >= 0:
    bruch1 = eingabe[0:position]
    bruch2 = eingabe[position + 1:len(eingabe)]
    zaehler1, nenner1 = bruch1.split("/")
    zaehler2, nenner2 = bruch2.split("/")

    if int(nenner1) == 0 or int(nenner2) == 0:
        print("Nenner darf nicht 0 sein")
    else:
        if operation == "+":
            zaehler, nenner = add(int(zaehler1), int(nenner1), int(zaehler2), int(nenner2))
        elif operation == "*":
            zaehler, nenner = mult(int(zaehler1), int(nenner1), int(zaehler2), int(nenner2))
        print("= " + str(zaehler) + "/" + str(nenner))
