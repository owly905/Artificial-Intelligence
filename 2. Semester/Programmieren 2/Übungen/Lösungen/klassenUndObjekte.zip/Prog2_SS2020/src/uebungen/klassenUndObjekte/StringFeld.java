package uebungen.klassenUndObjekte;

public class StringFeld {

	public static void main(String[] args) {
		String[] stringFeld = {
			"Java  Strings", "ist sind", "cool toll"
		};
		
		// erste H�lfte jedes Strings ausgeben
		for (String s : stringFeld) {
			System.out.println(s.substring(0, s.length()/2));
		}
		// zweite H�lfte jedes Strings ausgeben
		for (String s : stringFeld) {
			System.out.println(s.substring(s.length()/2));
		}
		// Strings ausgeben, die "cool" enthalten
		for (String s : stringFeld) {
			if (s.indexOf("cool") != -1) {
				System.out.println(s);
			}
		}
	}

}
