package uebungen.klassenUndObjekte;

public class Rechteck {
	private int hoehe, breite;
	
	public Rechteck(int hoehe, int breite) {
		this.hoehe = hoehe;
		this.breite = breite;
	}

	public int flaeche() {
		return hoehe * breite;
	}
	
	@Override
	public boolean equals(Object anderesObjekt) {
		// wir k�nnen nur Rechtecke miteinander vergleichen
		// �bergebenes Objekt muss ein Rechteck sein, also
		// durch "TypeCast" umwandeln!
		// Achtung: wird kein Rechteck �bergeben, wird hier eine
		// ClassCastException geworfen und das Programm terminiert!
		Rechteck anderesRechteck = (Rechteck) anderesObjekt; 
		boolean gleich = flaeche() == anderesRechteck.flaeche();
		return gleich;
	}

	public static void main(String[] args) {
		Rechteck r1 = new Rechteck(3, 4);
		Rechteck r2 = new Rechteck(2, 6);
		
		if (r1.equals(r2)) {
			System.out.println("gleich!");
		} else {
			System.out.println("ungleich!");			
		}
	}
}
