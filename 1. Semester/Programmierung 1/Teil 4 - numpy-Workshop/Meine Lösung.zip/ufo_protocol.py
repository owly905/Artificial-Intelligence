from matplotlib import pyplot as plt
import numpy as np

protocol_x = []
protocol_y = []

def add_to_protocol(p):
    protocol_x.append(p[0])
    protocol_y.append(p[1])

def plot_protocol(destinations):
    plt.title("Ufo Flight Protocol")
    plt.xlabel("x")
    plt.ylabel("y")

    protocol_x.append(0)
    protocol_y.append(0)

    plt.plot(protocol_x, protocol_y)
    plt.plot(protocol_x, protocol_y, "oy")
    plt.show()
