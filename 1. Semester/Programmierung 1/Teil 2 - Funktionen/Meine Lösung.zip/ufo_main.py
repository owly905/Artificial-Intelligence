from py4j.java_gateway import JavaGateway
from ufo_autopilot import flight_distance
from ufo_autopilot import fly_to

# Initialisierung des Gateways
gateway = JavaGateway()

# Referenz auf Simulation
sim = gateway.entry_point
sim.reset()

# View-Fenster, Skalierung (x m pro Pixel).
sim.openViewWindow(False, True, 5)

# Ziels x, y und Flughöhe z
x = float(input("x: "))
y = float(input("y: "))
z = float(input("z: "))
sim.addDestination(x, y)

# Simulationsgeschwindigkeit
sim.setSpeedup(2)

# auf Eingabe warten
input("Press return to start...")

# zu fliegenden Distanz
print("flight-distance: {}".format(flight_distance(0, 0, x, y, z)))

# Fliege das Ufo zum Ziel
fly_to(sim, x, y, z)

# tatsächlich geflogenen Distanz
print("actual flight-distance: {}".format(sim.getDist()))
