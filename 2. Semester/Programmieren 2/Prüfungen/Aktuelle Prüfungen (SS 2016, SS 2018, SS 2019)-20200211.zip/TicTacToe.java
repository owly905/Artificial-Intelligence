package klausur;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class TicTacToe extends Application {
	Label nachrichtLabel;
	private TicTacToeButton[][] buttons;
	private final int dimension = 3;
	private boolean spielGewonnen = false;
	private char zeichen = 'x';
	private EventHandler<ActionEvent> buttonHandler = event -> {
		if (spielGewonnen)
			return;
		// Zug durchf�hren
		TicTacToeButton button = (TicTacToeButton) event.getSource();
		button.setZeichen(zeichen);
		
		// Gewonnen?
		if (gewonnen()) {
			nachrichtLabel.setText(zeichen + " hat gewonnen!");
			spielGewonnen = true;
			return;
		}
		
		// Anzeige n�chster Zug
		if (zeichen == 'x') 
			zeichen = 'o';
		else
			zeichen = 'x';
		nachrichtLabel.setText(zeichen + " ist am Zug");
	};

	public static void main(String[] args) {
		launch(args);
	}

	public void start(Stage stage) {
		stage.setTitle("TicTacToe");		
		nachrichtLabel = new Label("x ist am Zug");
		buttons = new TicTacToeButton[dimension][dimension];
		GridPane gridPane = new GridPane();
		
		for (int i = 0; i < dimension; ++i) {
			for (int j = 0; j < dimension; ++j) {
				buttons[i][j] = new TicTacToeButton(' ');
				buttons[i][j].setOnAction(buttonHandler);
				gridPane.add(buttons[i][j], j, i);
			}
		}
		
		BorderPane mainPane = new BorderPane();
		Scene scene = new Scene(mainPane);
		mainPane.setCenter(gridPane);
		mainPane.setBottom(nachrichtLabel);
		stage.setScene(scene);
		stage.show();
	}
	
	private boolean gewonnen() {
		boolean ergebnis = 
				(buttons[0][0].getZeichen() == zeichen &&
				 buttons[0][1].getZeichen() == zeichen &&
				 buttons[0][2].getZeichen() == zeichen) ||
				(buttons[1][0].getZeichen() == zeichen &&
				 buttons[1][1].getZeichen() == zeichen &&
				 buttons[1][2].getZeichen() == zeichen) ||
				(buttons[2][0].getZeichen() == zeichen &&
				 buttons[2][1].getZeichen() == zeichen &&
				 buttons[2][2].getZeichen() == zeichen) ||
				(buttons[0][0].getZeichen() == zeichen &&
				 buttons[1][0].getZeichen() == zeichen &&
				 buttons[2][0].getZeichen() == zeichen) ||
				(buttons[0][1].getZeichen() == zeichen &&
				 buttons[1][1].getZeichen() == zeichen &&
				 buttons[2][1].getZeichen() == zeichen) ||
				(buttons[0][2].getZeichen() == zeichen &&
				 buttons[1][2].getZeichen() == zeichen &&
				 buttons[2][2].getZeichen() == zeichen) ||
				(buttons[0][0].getZeichen() == zeichen &&
				 buttons[1][1].getZeichen() == zeichen &&
				 buttons[2][2].getZeichen() == zeichen) ||
				(buttons[2][0].getZeichen() == zeichen &&
				 buttons[1][1].getZeichen() == zeichen &&
				 buttons[0][2].getZeichen() == zeichen);
		return ergebnis;
	}
}
