# Winkel zwischen zwei Vektoren
# https://www.jwwalker.com/pages/angle-between-vectors.html
from math import degrees, atan2

# Startpunkt
x1 = float(input("x1: "))
y1 = float(input("y1: "))

# Zielpunkt
x2 = float(input("x2: "))
y2 = float(input("y2: "))

# Hilfspunkt: Rechts vom Startpunkt, Vektorberechnung
x3 = x1 + 1
y3 = y1

# Winkelberechnung
winkel = degrees(atan2(abs(y2-y1), (x2-x1)))

if y2 >= y1:
    print(winkel) # Z über S
else:
    print(360 - winkel) # y2 < y1, Z über E

###############################################################################

# Taylorreihe für Kosinus
from math import factorial, cos

# x-Wert für cos(x)
x = float(input("Annaeherung für cos(x), x: "))
# n Schritte der Annaeherung
n = int(input("n Annaeherungsschritte: "))

# Startwert der Summe
summe = 1
# Zählervariable i
i = 1
# Vorzeichenwechsel
vz = -1

# Hilfsvariable für Fakultaet
fak = 1
# Hilfsvariable für Potenz
pot = x * x

while i < n:
    # Neuer Fakultaetwert
    fak *= (2*i-1) * (2*i)

    summe += vz * pot / fak

    # Neuer Potenzwert
    pot *= x * x    
    vz *= -1
    i += 1

# Ausgabe des Werte durch Annaeherung
print("\ncos({}) = {}".format(x, summe))

# Ausgabe der Fehlerdifferenz 
fehler = cos(x) - summe
print("Fehler: {}".format(fehler))

###############################################################################

# Flugdaten
# dt = 0.5, dx = 5.25, dy = -0.18, dz - input
# t - z: 5 Zeichen
# x - y: 6 Zeichen

# Startparameter
t = 0.0
dt = 0.5

x = 0.0
dx = 5.25

y = -0.0
dy = -0.18

z = 0.0
dz = float(input("dz: "))

print("{:>5}{:5}{:>6} {:>6} {:>5}".format("t ", "", "x ", "y ", "z "))

for i in range(21):
    print("{:5.1f} s: [{:6.1f} {:6.1f} {:5.1f}]".format(t, x, y, z))
    t += dt
    x += dx
    y += dy
    z += dz