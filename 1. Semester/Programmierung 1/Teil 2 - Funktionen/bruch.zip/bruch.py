def ggt(a, b):
    if a < 0:
        a = -a
    
    if b < 0:
        b = -b

    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    
    return a

def kuerze(zaehler, nenner):
    if zaehler != 0 and nenner != 0:
        teiler = ggt(zaehler, nenner)
        return zaehler//teiler, nenner//teiler
    else:
        return zaehler, nenner

def normal(zaehler, nenner):
    zaehler, nenner = kuerze(zaehler, nenner)

    if nenner < 0:
        zaehler, nenner = -zaehler, -nenner

    return zaehler, nenner
    
def add(zaehler1, nenner1, zaehler2, nenner2):
    zaehler = zaehler1 * nenner2 + zaehler2 * nenner1
    nenner = nenner1 * nenner2
    return normal(zaehler, nenner)

def mult(zaehler1, nenner1, zaehler2, nenner2):
    zaehler = zaehler1 * zaehler2
    nenner = nenner1 * nenner2
    return normal(zaehler, nenner)
