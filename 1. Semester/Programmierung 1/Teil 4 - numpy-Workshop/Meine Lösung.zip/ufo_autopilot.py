import math
from ufo_protocol import add_to_protocol

def distance(s, p):
    x_part = (p[0]-s[0]) * (p[0]-s[0])
    y_part = (p[1]-s[1]) * (p[1]-s[1])
    return math.sqrt(x_part + y_part)

def angle(s, p):
    winkel = math.degrees(math.atan2(abs(p[1]-s[1]), (p[0]-s[0])))
    if p[1] >= s[1]:
        return winkel
    else:
        return 360 - winkel

def flight_distance(s, p, z):
    return 2 * z + distance(s, p)

def flight_distance_mult(destinations, z):
    dist = flight_distance((0,0), destinations[0], z)
    for i in range(0, len(destinations)-1):
        dist += flight_distance(destinations[i], destinations[i+1], z)
    else:
        dist += flight_distance(destinations[-1], (0,0), z)
    return dist

def format_flight_data(sim):
    return "{:5.1f} s: [{:6.1f} {:6.1f} {:5.1f}]".format(
        sim.getTime(), sim.getX(), sim.getY(), sim.getZ())

def fly_to(sim, p, z):
    takeoff(sim, z)
    cruise(sim, p)
    landing(sim)

def takeoff(sim, z):
    # senkrecht nach oben mit 10 km/h auf z m
    print(format_flight_data(sim) +
        " takeoff with 10 km/h to alt {} m...".format(z))
    sim.setI(90)
    sim.requestDeltaV(10)

    # vor Erreichen der Zielhoehe, abbremsen auf 1 km/h
    while sim.getZ() < z - 2:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h... ")
    sim.requestDeltaV(-9)
    
    # kurz vor z, stoppt und richtet sich horizontal aus
    while sim.getZ() < z - 0.05:
        pass
    print(format_flight_data(sim) + " ...stop and turn horizontal")
    sim.requestDeltaV(-1)
    sim.setI(0)

def cruise(sim, p):
    # Das Ufo ist in der aktuellen Position gestartet.
    fro_s = (sim.getX(), sim.getY())

    # im Protokol hinzufügen
    add_to_protocol(fro_s)

    # in Richtung Ziel (Winkel), zu fliegende Distanz ist dist.
    sim.setD(int(angle(fro_s, p)))
    dist = sim.getDist() + distance(fro_s, p)
    
    # auf 15 km/h beschleunigen
    print(format_flight_data(sim) + " go {} deg with 15 km/h...".format(
        int(angle(fro_s, p))))
    sim.requestDeltaV(15)
    
    # Abstand zum Ziel 4m, auf 1 km/h abremsen
    while dist - sim.getDist() > 4:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h... ")
    sim.requestDeltaV(-14)

    # Abstand zum Ziel 0.05m, Stopp!
    while dist - sim.getDist() > 0.05:
        pass
    print(format_flight_data(sim) + " ...stop")
    sim.requestDeltaV(-1)

def landing(sim):
    # senkrecht nach unten mit 10 km/h
    print(format_flight_data(sim) + " landing with 10 km/h")
    sim.setI(-90)
    sim.requestDeltaV(10)
    
    # Hoehe 3m, auf 1 km/h abbremsen
    while sim.getZ() > 3:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h...")
    sim.requestDeltaV(-9)
    
    # gelandet, wenn Hoehe kleiner gleich 0
    while sim.getZ() > 0:
        pass
    print(format_flight_data(sim) + " ...happily landed")

def distance_from_zero(p):
    return distance((0,0), p)
