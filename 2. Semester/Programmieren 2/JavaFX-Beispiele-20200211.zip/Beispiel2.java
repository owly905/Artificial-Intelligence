package kap8;

import java.net.URL;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * JavaFx-Beispielanwendung zur Verdeutlichung der erkl�rten Layout-Komponenten (Panes)
 * sowie einiger der Controls.
 * 
 * @author Hans-Michael Windisch
 */
public class Beispiel2 extends Application {
	private TextArea messagesArea = new TextArea("");
	
	private void createAndAddButton(GridPane grid, int buttonNumber, URL url, String name) {
		Image image = new Image(url.toString());				// Image aus Bild erzeugen
		ImageView imageView = new ImageView(image);				// ImageView erzeugen zu Image
		imageView.setFitHeight(70);								// ImageView soll 70 Pixel hoch sein
		imageView.setFitWidth(100);								// ImageView soll 100 Pixel breit sein
		Button imgButton = new Button(String.format("%s%02d", 	// Button mit Text und Bild erzeugen
				name, buttonNumber + 1), imageView);
		imgButton.setContentDisplay(ContentDisplay.TOP);		// Bild soll oben sein (Text damit unten)
		imgButton.setOnAction(event -> messagesArea.setText(	// Button-Klick bewirkt Ausgabe auf messages-Textarea
			"Button " + imgButton.getText() + 
			" gedr�ckt" + "\n" + messagesArea.getText()));
		grid.add(imgButton, buttonNumber % 5, buttonNumber / 5);// Button zu Grid hinzuf�gen
	}

	private void okAction(TextField anzahlFeld, TextField nameFeld, GridPane grid, URL url1) {
		int anzahl = Math.min(25, 
				new Integer(anzahlFeld.getText()));				// Anzahl der zu erzeugenden Buttons aus Textfeld holen
		// Meldung anzeigen
		messagesArea.setText(
			"Erzeuge " + anzahl + " Buttons, Name = " + nameFeld.getText() + "\n" +
			messagesArea.getText());
		// 'anzahl' Buttons in 5x5-Grid anzeigen
		grid.getChildren().clear();									// Grid l�schen
		for (int i = 0; i < anzahl; ++i) {							// Anzahl Buttons hinzuf�gen
			createAndAddButton(grid, i, url1, nameFeld.getText());
		}
	}
	
	/**
	 * Initialisiert das Fenster 
	 * @param primaryStage Fenster, welches initialisiert werden soll.
	 */
	private void init(Stage primaryStage) {
		// GridPane f�r Button-Matrix im Center-Bereich
		// wird vorab definiert, damit man im OK-Button-Handler darauf zugreifen kann
		GridPane grid = new GridPane();
		// Titel setzen
		primaryStage.setTitle("Beispiel 2");
		// als top-level Layout nutzen wir eine BorderPane mit den 
		// Bereichen top, left, center, bottom (right ist ungenutzt)
		BorderPane borderPane = new BorderPane();
		
		/*
		 * TOP-Bereich mit ImageView zur Darstellung eines Bildes
		 */
		// Url f�r Bild erzeugen
		URL url1 = Beispiel2.class.getResource("javafx.png");		// URL f�r Bild erzeugen
		URL url2 = Beispiel2.class.getResource(
				"thi_logo_wb_RGB.jpg");								// URL f�r Bild erzeugen
		FlowPane topPane = new FlowPane();							// FlowPane f�r top-Bereich erzeugen
		topPane.setStyle("-fx-background-color: white"); 			// weisser Hintergrund
		ImageView imageView = new ImageView(url2.toString());		
		imageView.setFitHeight(100);								// H�he setzen
		imageView.setFitWidth(220);									// Breite setzen
		topPane.getChildren().add(imageView);						// ImageView in topPane setzen
		borderPane.setTop(topPane);									// topPane in top-Bereich setzen

		VBox leftPane = new VBox(10); 								// VBox mit 10pixel Abstand der Kinder 
		leftPane.setPadding(new Insets(5));							// Abst�nde zum �usseren Rand auf 5 Pixel setzen
		HBox zeile1 = new HBox();									// HBox f�r 1. Zeile
		Label nameLabel = new Label("Name: ");						// Label f�r 1. Zeile
		nameLabel.setPrefWidth(50);									// Breite des Labels setzen
		zeile1.setAlignment(Pos.CENTER_LEFT);						// Positionierung: vertikal zentriert, horizontal linksb�ndig
		TextField nameFeld = new TextField();						// Textfeld f�r Name
		zeile1.getChildren().addAll(nameLabel, nameFeld);			// Label und Textfeld zu Zeil1 hinzuf�gen

		HBox zeile2 = new HBox();									// analog Zeile1
		Label anzahlLabel = new Label("Anzahl: ");
		anzahlLabel.setPrefWidth(50);
		zeile2.setAlignment(Pos.CENTER_LEFT);
		TextField anzahlFeld = new TextField();
		anzahlFeld.setOnKeyPressed(new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent ke) {
	            if (ke.getCode().equals(KeyCode.ENTER)) {
	                okAction(anzahlFeld, nameFeld, grid, url1);
	            }
	        }
	    });
		zeile2.getChildren().addAll(anzahlLabel, anzahlFeld);
		
		HBox zeile3 = new HBox();									// HBox f�r 3 . Zeile
		zeile3.setAlignment(Pos.CENTER_RIGHT);						// Positionierung: vertikal zentriert, horizontal rechtsb�ndig
		Button okButton = new Button("OK");							// OK-Button
		okButton.setOnAction(e -> {									// Action f�r OK-Button: Meldung anzeigen, <anzahl> Buttons in Grid erzeugen
            okAction(anzahlFeld, nameFeld, grid, url1);
		});
		zeile3.getChildren().addAll(okButton);							// ok-Button zu Zeile 3 hinzuf�gen 
		
		leftPane.getChildren().addAll(zeile1, zeile2, zeile3);			// alle Zeilen zu leftPane hinzuf�gen
		borderPane.setLeft(leftPane);									// leftPane in linken Bereich der BorderPane setzen

		grid.setAlignment(Pos.TOP_LEFT);
		for (int i = 0; i < 5; ++i) {
			for (int j = 0; j < 5; ++j) {
				createAndAddButton(grid, i*5 + j, url1, nameFeld.getText());
			}
		}
		grid.setGridLinesVisible(false);
		borderPane.setCenter(grid);
		
		// Bottom content
		VBox bottomPane = new VBox();
		bottomPane.getChildren().addAll(new Label("Messages:"), messagesArea);
		borderPane.setBottom(bottomPane);

		Scene scene = new Scene(borderPane);
		primaryStage.setScene(scene);
	}

	@Override
	/**
	 * Start-Methode von JavaFX. Wird automatisch von launch() aufgerufen...
	 * @param primaryStage erstes (und hier: einziges) Fenster
	 */
	public void start(Stage primaryStage) throws Exception {
		init(primaryStage);
		// Fenster anzeigen
		primaryStage.show(); 
	}

	public static void main(String[] args) {
		// Anwendung starten
		launch();
	}
}
