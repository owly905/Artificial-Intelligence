package uebungen.klassenUndObjekte;

public class Person {

	/**
	 * Attribute jedes Personenobjekts
	 */
	int alter;
	String name;
	
	/**
	 * Konstruktor zum Erzeugen von Pesonenobjekten.
	 * Eine Person wird bei Erzeugung initialisiert �ber die Parameter f�r Name und Alter.
	 */
	Person(String nameInit, int alterInit) {
		name = nameInit;
		alter = alterInit;
	}

	/**
	 * Eine Person kann sich auf den Bildschirm ausgeben 
	 */
	void ausgeben() {
		System.out.println("Name: " + name + ", Alter: " + alter);
	}
	
	/**
	 * Hauptfunktion
	 * @param args Kommandozeilenargumente (nicht verarbeitet)
	 */
	static public void main(String[] args) {
		Person peter = new Person("Peter", 20);
		Person amelie = new Person("Amelie", 29);
		
		peter.ausgeben();
		amelie.ausgeben();
	}
}
