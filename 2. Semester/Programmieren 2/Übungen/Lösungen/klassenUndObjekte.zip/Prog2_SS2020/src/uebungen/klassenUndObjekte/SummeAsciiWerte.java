package uebungen.klassenUndObjekte;

public class SummeAsciiWerte {

	public static void main(String[] args) {
		char[] charFeld = new char[26];
		
		// Feld belegen mit 'A' .. 'Z'
		for (int i = 0; i < charFeld.length; ++i) {
			charFeld[i] = (char) ('A' + i);
		}
		
		// Summe der ASCII-Werte berechnen
		int summe = 0;
		for (int i = 0; i < charFeld.length; ++i) {
			summe += charFeld[i];
		}
		
		// Buchstaben und Summe ausgeben
		for (int i = 0; i < charFeld.length; ++i) {
			System.out.print(charFeld[i]);
		}		
		System.out.println("\nSumme: " + summe);
	}
}
