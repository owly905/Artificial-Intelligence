def ggt(a, b):
    if a < 0:
        a = -a
    
    if b < 0:
        b = -b

    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    
    return a

def kuerze(bruch):
    (zaehler, nenner) = bruch
    if zaehler != 0 and nenner != 0:
        teiler = ggt(zaehler, nenner)
        return (zaehler//teiler, nenner//teiler)
    else:
        return (zaehler, nenner)

def normal(bruch):
    zaehler, nenner = kuerze(bruch)

    if nenner < 0:
        (zaehler, nenner) = (-zaehler, -nenner)

    return (zaehler, nenner)
    
def add(bruch1, bruch2):
    (zaehler1, nenner1) = bruch1
    (zaehler2, nenner2) = bruch2
    ergebnis = (zaehler1 * nenner2 + zaehler2 * nenner1, nenner1 * nenner2)
    return normal(ergebnis)

def mult(bruch1, bruch2):
    (zaehler1, nenner1) = bruch1
    (zaehler2, nenner2) = bruch2
    ergebnis = (zaehler1 * zaehler2, nenner1 * nenner2)
    return normal(ergebnis)
