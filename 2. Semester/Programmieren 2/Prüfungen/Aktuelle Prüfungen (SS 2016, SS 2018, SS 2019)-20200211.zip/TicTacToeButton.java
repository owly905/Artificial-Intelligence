package klausur;

import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

@SuppressWarnings("serial")
public class TicTacToeButton extends Button {
	private final String IMAGE_PATH = "/pic/";
	private char zeichen;
	
	public TicTacToeButton(char zeichen) {
		setZeichen(zeichen);
	}
	
	// Liefert das aktuelle Zeichen ('x' oder 'o')
	public char getZeichen() {
		return zeichen;
	}
	
	public void setZeichen(char zeichen) {
		this.zeichen = zeichen;

		try {
			String zeichenString = "" + zeichen;
			Image icon = null;
			
			if (zeichen == ' ')
				zeichenString = "leer";
				
			String filename = IMAGE_PATH + zeichenString + ".jpg";
			icon = new Image(filename);
			setGraphic(new ImageView(icon));
			setContentDisplay(ContentDisplay.TOP);
			setPrefSize(100, 100);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
