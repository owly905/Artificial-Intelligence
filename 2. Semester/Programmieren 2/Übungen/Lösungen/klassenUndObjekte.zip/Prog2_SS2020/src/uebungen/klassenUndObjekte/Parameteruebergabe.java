package uebungen.klassenUndObjekte;

class AddErgebnis {
	private int wert;

	public void setWert(int wert) {
		this.wert = wert;
	}

	public int getWert() {
		return wert;
	}
}

public class Parameteruebergabe {

	static void add(int x, int y, AddErgebnis erg) {
		erg.setWert(x + y);
	}
	
	public static void main(String[] args) {
		AddErgebnis ergebnis = new AddErgebnis();
		add(3, 5, ergebnis);
		System.out.println("3 + 5 = " + ergebnis.getWert());
	}
}
