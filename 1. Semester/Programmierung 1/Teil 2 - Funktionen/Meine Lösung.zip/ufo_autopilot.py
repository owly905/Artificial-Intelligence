import math

def distance(x1, y1, x2, y2):
    x_part = (x2-x1) * (x2-x1)
    y_part = (y2-y1) * (y2-y1)
    return math.sqrt(x_part + y_part)

def angle(x1, y1, x2, y2):
    winkel = math.degrees(math.atan2(abs(y2-y1), (x2-x1)))
    if y2 >= y1:
        return winkel
    else:
        return 360 - winkel

def flight_distance(x1, y1, x2, y2, z):
    return 2 * z + distance(x1, y1, x2, y2)

def format_flight_data(sim):
    return "{:5.1f} s: [{:6.1f} {:6.1f} {:5.1f}]".format(
        sim.getTime(), sim.getX(), sim.getY(), sim.getZ())

def fly_to(sim, x, y, z):
    takeoff(sim, z)
    cruise(sim, x, y)
    landing(sim)

def takeoff(sim, z):
    # senkrecht nach oben mit 10 km/h auf z m
    print(format_flight_data(sim) +
        " takeoff with 10 km/h to alt {} m...".format(z))
    sim.setI(90)
    sim.requestDeltaV(10)

    # vor Erreichen der Zielhoehe, abbremsen auf 1 km/h
    while sim.getZ() < z - 2:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h... ")
    sim.requestDeltaV(-9)
    
    # kurz vor z, stoppt und richtet sich horizontal aus
    while sim.getZ() < z - 0.05:
        pass
    print(format_flight_data(sim) + " ...stop and turn horizontal")
    sim.requestDeltaV(-1)
    sim.setI(0)

def cruise(sim, x, y):
    # Das Ufo ist in der aktuellen Position gestartet.
    fro_x = sim.getX()
    fro_y = sim.getY()

    # in Richtung Ziel (Winkel), zu fliegende Distanz ist dist.
    sim.setD(int(angle(fro_x, fro_y, x, y)))
    dist = sim.getDist() + distance(fro_x, fro_y, x, y)
    
    # auf 15 km/h beschleunigen
    print(format_flight_data(sim) + " go {} deg with 15 km/h...".format(
        int(angle(fro_x, fro_y, x, y))))
    sim.requestDeltaV(15)
    
    # Abstand zum Ziel 4m, auf 1 km/h abremsen
    while dist - sim.getDist() > 4:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h... ")
    sim.requestDeltaV(-14)

    # Abstand zum Ziel 0.05m, Stopp!
    while dist - sim.getDist() > 0.05:
        pass
    print(format_flight_data(sim) + " ...stop")
    sim.requestDeltaV(-1)

def landing(sim):
    # senkrecht nach unten mit 10 km/h
    print(format_flight_data(sim) + " landing with 10 km/h")
    sim.setI(-90)
    sim.requestDeltaV(10)
    
    # Hoehe 3m, auf 1 km/h abbremsen
    while sim.getZ() > 3:
        pass
    print(format_flight_data(sim) + " ...slow down to 1 km/h...")
    sim.requestDeltaV(-9)
    
    # gelandet, wenn Hoehe kleiner gleich 0
    while sim.getZ() > 0:
        pass
    print(format_flight_data(sim) + " ...happily landed")

memo = {1:1,}
def fac(n):
    if n <= 0:
        return None
    if not n in memo:
        memo[n] = n * fac(n-1)
    return memo[n]