package kap8;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class Labels extends Application {
	private TextArea protokollTextArea = new TextArea();
	
	private FlowPane initLabels() {
		FlowPane pane = new FlowPane();
		pane.setHgap(20); // Abstand setzen
		// Hintergrundfarbe als CSS Style setzen
		pane.setStyle("-fx-background-color: yellow;");
		Label label1 = new Label("einfach mit der Maus drüber fahren!");
		label1.setOnMouseEntered(e -> protokollTextArea.setText("Mausalarm für " + label1.getText() +
				"\n" + protokollTextArea.getText()));
		Label label2 = new Label("Label 2 (style: fett)");
		label2.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		label2.setTextFill(Color.web("red"));
		pane.getChildren().addAll(new Label("Labels: "), label1, label2);
		return pane;
	}
	
	public void start(Stage primaryStage) throws Exception {
		VBox vertikalBox = new VBox();
		vertikalBox.setSpacing(10);
		vertikalBox.getChildren().add(initLabels());
		vertikalBox.getChildren().add(protokollTextArea);
		protokollTextArea.setText("einfach ein Label anklicken!");		
		primaryStage.setTitle("Label-Demo");
		primaryStage.setScene(new Scene(vertikalBox));
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
