import itertools
from ufo_autopilot import flight_distance_mult
from operator import itemgetter

def fac(n):
    if n <= 1:
        return 1
    else:
        return n * fac(n-1)

def find_shortest_route(destinations):
    routes_dist = []
    routes = list(itertools.permutations(destinations))
    for route in routes:
        routes_dist.append(flight_distance_mult(route, z=0))
    return routes[routes_dist.index(min(routes_dist))]
