package kap09.controls;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class Beispiel3 extends Application {

	final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");
	
	/*
	 * Statische innerere Klassen f�r Abteilung und Mitarbeiter
	 * nicht-statische innere Klassen haben Zugriff zu den Eigenschaften der umgebenden Klasse, statische nicht.
	 */
	public static class Abteilung {
		private String bezeichnung;
		private Mitarbeiter leitung;
		private List<Mitarbeiter> mitarbeiter;
		
		public Abteilung(String bezeichnung, Mitarbeiter leitung, List<Mitarbeiter> mitarbeiter) {
			this.bezeichnung = bezeichnung;
			this.leitung = leitung;
			this.mitarbeiter = mitarbeiter;
		}
		public String getBezeichnung() {
			return bezeichnung;
		}
		public Mitarbeiter getLeitung() {
			return leitung;
		}
		public List<Mitarbeiter> getMitarbeiter() {
			return mitarbeiter;
		}
		public void setBezeichnung(String bezeichnung) {
			this.bezeichnung = bezeichnung;
		}
		public void setLeitung(Mitarbeiter leitung) {
			this.leitung = leitung;
		}
		public void setMitarbeiter(List<Mitarbeiter> mitarbeiter) {
			this.mitarbeiter = mitarbeiter;
		}
		@Override
		public String toString() {
			return bezeichnung;
		}
	}

	/*
	 * Mitarbeiter-Klasse mit Properties f�r den Datenaustausch mit der TableView
	 */
	public static class Mitarbeiter {
		private StringProperty name;
		private ObjectProperty<LocalDate> eingestelltSeit;
		private IntegerProperty stundenProTag;
		private BooleanProperty festangestellt;
		
		public Mitarbeiter() {
		}
		
		public Mitarbeiter(String name, LocalDate eingestelltSeit, int stundenProTag, boolean festangestellt) {
			this.name = new SimpleStringProperty(this, "name", name);
			this.eingestelltSeit = new SimpleObjectProperty<LocalDate>(this, "eingestelltSeit", eingestelltSeit);
			this.stundenProTag = new SimpleIntegerProperty(this, "stundenProTag", stundenProTag);
			this.festangestellt = new SimpleBooleanProperty(this, "festangestellt", festangestellt);
		}
		public String getName() {
			return name.getValue();
		}
		public LocalDate getEingestelltSeit() {
			return eingestelltSeit.getValue();
		}
		public int getStundenProTag() {
			return stundenProTag.get();
		}
		public boolean isFestangestellt() {
			return festangestellt.getValue();
		}
		public void setName(String name) {
			this.name.setValue(name);
		}
		public void setEingestelltSeit(LocalDate eingestelltSeit) {
			this.eingestelltSeit.setValue(eingestelltSeit);
		}
		public void setStundenProTag(int stundenProTag) {
			this.stundenProTag.setValue(stundenProTag);
		}
		public void setFestangestellt(boolean festangestellt) {
			this.festangestellt.setValue(festangestellt);
		}
		@Override
		public String toString() {
			return name.get() + ", eingestelltSeit=" + eingestelltSeit.get() + 
					", stundenProTag=" + stundenProTag.get()
					+ ", festangestellt=" + festangestellt.get() + "]";
		}
	}
	
	private TextArea protokollTextArea = new TextArea();
	private HashMap<String, Mitarbeiter> mitarbeiter = new HashMap<>();
	private HashMap<String, Abteilung> abteilungen = new HashMap<>();
	private final ObservableList<Mitarbeiter> mitarbeiterListe = FXCollections.observableArrayList();

	/**
	 * Erzeugt ein TableColumn-Objekt f�r eine Spalte.
	 * @param property Attributname in Mitarbeiter-Klasse
	 * @param title Spalten-Titel
	 * @param type Datentyp des Attributs
	 * @param width Spaltenbreite
	 * @return erzeugtes TableColumn-Objekt
	 */
    private <T> TableColumn<Mitarbeiter, T> createTableColumn(String property, String title, Class<T> type, int width) {
        TableColumn<Mitarbeiter, T> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<Mitarbeiter, T>(property));
        column.setEditable(true);
        column.setPrefWidth(width);
        return column;
    }
	
	private Node initMitarbeiterPane() {
		FlowPane pane = new FlowPane();
		pane.setHgap(20); // Abstand setzen
		// Hintergrundfarbe als CSS Style setzen
		pane.setStyle("-fx-background-color: lightgrey");
		
		/*
		 * TableView erzeugen
		 */
		TableView<Mitarbeiter> tableView = new TableView<>(mitarbeiterListe);
        tableView.setEditable(true);
        tableView.setMinWidth(400);

		/*
		 * Spalten definieren und der tableView bekannt machen
		 */
        TableColumn<Mitarbeiter, String> bezeichnungColumn = createTableColumn("name", "Name", String.class, 150);
		TableColumn<Mitarbeiter, LocalDate> eingestelltColumn = createTableColumn("eingestelltSeit", "Eingestellt", LocalDate.class, 100);
		TableColumn<Mitarbeiter, Integer> stundenColumn = createTableColumn("stundenProTag", "Stunden/Tag", Integer.class, 100);
		TableColumn<Mitarbeiter, Boolean> festangestelltColumn = createTableColumn("festangestellt", "Festangestellt", Boolean.class, 100);

		/*
		 * Zum Editieren m�ssen 2 Dinge vorbereitet werden f�r jede Spalte:
		 * 1. CellFactory setzen - au�er f�r "String" (=Textfeld) muss dabei die Konvertierung
		 *    in String bzw. von String implementiert werden (Datentransfer von Mitarbeiter-Objekt
		 *    in Tabellenzelle (String!) und zur�ck)
		 * 2. Handler zum Speichern des neuen Feldwertes nach dem Editieren 
		 */
		bezeichnungColumn.setCellFactory(TextFieldTableCell.forTableColumn());
		bezeichnungColumn.setOnEditCommit(
		    new EventHandler<CellEditEvent<Mitarbeiter, String>>() {
		        @Override
		        public void handle(CellEditEvent<Mitarbeiter, String> s) {
		            ((Mitarbeiter) s.getTableView().getItems().get(
		            		s.getTablePosition().getRow())).setName(s.getNewValue());
		        }
		    }
		);
		
		eingestelltColumn.setCellFactory(TextFieldTableCell.forTableColumn(
			new StringConverter<LocalDate>() {
	            @Override
	            public String toString(LocalDate t) {
	                if (t == null) {
	                    return "" ;
	                } else {
	                    return dateFormat.format(t);
	                }
	            }
	            @Override
	            public LocalDate fromString(String string) {
	                try {
	                    return LocalDate.parse(string, dateFormat);
	                } catch (DateTimeParseException exc) {
	                	exc.printStackTrace();
	                    return null;
	                }
	            }
	        }));
		eingestelltColumn.setOnEditCommit(
		    new EventHandler<CellEditEvent<Mitarbeiter, LocalDate>>() {
		        @Override
		        public void handle(CellEditEvent<Mitarbeiter, LocalDate> d) {
		            ((Mitarbeiter) d.getTableView().getItems().get(
		            		d.getTablePosition().getRow())).setEingestelltSeit(d.getNewValue());
		        }
		    }
		);

		stundenColumn.setCellFactory(TextFieldTableCell.forTableColumn(
				new StringConverter<Integer>() {
		            @Override
		            public String toString(Integer i) {
		                if (i == null) {
		                    return "" ;
		                } else {
		                    return "" + i;
		                }
		            }
		            @Override
		            public Integer fromString(String string) {
		                try {
		                    return new Integer(string);
		                } catch (DateTimeParseException exc) {
		                	exc.printStackTrace();
		                    return null;
		                }
		            }
		        }));
		stundenColumn.setOnEditCommit(
			    new EventHandler<CellEditEvent<Mitarbeiter, Integer>>() {
			        @Override
			        public void handle(CellEditEvent<Mitarbeiter, Integer> i) {
			            ((Mitarbeiter) i.getTableView().getItems().get(
			            		i.getTablePosition().getRow())).setStundenProTag(i.getNewValue());
			        }
			    }
			);

		festangestelltColumn.setCellFactory(TextFieldTableCell.forTableColumn(
				new StringConverter<Boolean>() {
		            @Override
		            public String toString(Boolean b) {
		                if (b == null) {
		                    return "" ;
		                } else {
		                    return b ? "true" : "false";
		                }
		            }
		            @Override
		            public Boolean fromString(String string) {
		                try {
		                    return new Boolean(string);
		                } catch (DateTimeParseException exc) {
		                	exc.printStackTrace();
		                    return null;
		                }
		            }
		        }));
		festangestelltColumn.setOnEditCommit(
			    new EventHandler<CellEditEvent<Mitarbeiter, Boolean>>() {
			        @Override
			        public void handle(CellEditEvent<Mitarbeiter, Boolean> b) {
			            ((Mitarbeiter) b.getTableView().getItems().get(
			            		b.getTablePosition().getRow())).setFestangestellt(b.getNewValue());
			        }
			    }
			);

		tableView.getColumns().addAll(bezeichnungColumn, eingestelltColumn, stundenColumn, festangestelltColumn);
        
        /*
         * Mehrfach-Selektion setzen und Handler f�r Zeilenselektion mit Maus
         * installieren
         */
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        tableView.setOnMouseClicked(e -> {
        	protokollTextArea.setText(tableView.getSelectionModel().getSelectedItems() + "\n" + protokollTextArea.getText());
        });
        pane.getChildren().addAll(new Label("Mitarbeiter: "), tableView);
		return pane;
	}

	public void start(Stage primaryStage) throws Exception {
		initDaten();
		BorderPane mainPane= new BorderPane();
		primaryStage.setTitle("Abteilungen und Mitarbeiter");
		mainPane.setLeft(initAbteilungsPane());
		mainPane.setCenter(initMitarbeiterPane());
		mainPane.setBottom(protokollTextArea);
		primaryStage.setScene(new Scene(mainPane));
		primaryStage.show();
	}

	private void initDaten() {
		try {
			// Mitarbeiter eintragen
			mitarbeiter.put("Codie", new Mitarbeiter("Codie", 
					LocalDate.parse("14.03.1975", dateFormat), 8, true));
			mitarbeiter.put("Joe", new Mitarbeiter("Joe", 
					LocalDate.parse("09.12.1999", dateFormat), 8, true));
			mitarbeiter.put("Anna", new Mitarbeiter("Anna", 
					LocalDate.parse("07.05.2002", dateFormat), 8, true));
			mitarbeiter.put("Jule", new Mitarbeiter("Jule", 
					LocalDate.parse("08.08.2001", dateFormat), 4, false));
			mitarbeiter.put("Sam", new Mitarbeiter("Sam", 
					LocalDate.parse("01.01.2000", dateFormat), 6, false));
			// Abteilungen eintragen
			List<Mitarbeiter> mitarbeiterEntwicklung = new ArrayList<>();
			mitarbeiterEntwicklung.add(mitarbeiter.get("Codie"));
			mitarbeiterEntwicklung.add(mitarbeiter.get("Joe"));
			List<Mitarbeiter> mitarbeiterVertrieb = new ArrayList<>();
			mitarbeiterVertrieb.add(mitarbeiter.get("Anna"));
			mitarbeiterVertrieb.add(mitarbeiter.get("Jule"));
			mitarbeiterVertrieb.add(mitarbeiter.get("Sam"));
			abteilungen.put("Entwicklung", new Abteilung("Entwicklung ", mitarbeiter.get("Codie"), mitarbeiterEntwicklung));		
			abteilungen.put("Vertrieb", new Abteilung("Vertrieb ", mitarbeiter.get("Anna"), mitarbeiterVertrieb));		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private Node initAbteilungsPane() {
		VBox vbox = new VBox();

		List<Abteilung> abteilungsliste = new ArrayList<>();
		abteilungsliste.addAll(abteilungen.values());
		ObservableList<Abteilung> observableList = FXCollections.observableList(abteilungsliste);
		
		ListView<Abteilung> listView = new ListView<>(observableList);
		listView.setMaxWidth(100);
		listView.setOnMouseClicked(e -> {
			Abteilung selektierteAbteilung = listView.getSelectionModel().getSelectedItem();
			mitarbeiterListe.clear();
			mitarbeiterListe.addAll(selektierteAbteilung.getMitarbeiter());
			protokollTextArea.setText("Auswahl: " + 
				listView.getSelectionModel().getSelectedItem() + "\n" + protokollTextArea.getText());
		});

		vbox.getChildren().addAll(new Label("Abteilungen: "), listView);
		return vbox;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
